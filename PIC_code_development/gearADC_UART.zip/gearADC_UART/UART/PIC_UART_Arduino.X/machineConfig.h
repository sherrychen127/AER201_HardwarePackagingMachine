/* 
 * File:   machineConfig.h
 * Author: Tyler Gamvrelis
 *
 * Created on July 10, 2017, 10:44 AM
 */

#ifndef MACHINECONFIG_H
#define	MACHINECONFIG_H

/********************************** Includes **********************************/
#include <xc.h>

/****************************** Public Interfaces *****************************/
void machineConfig(void);

#endif	/* MACHINECONFIG_H */

