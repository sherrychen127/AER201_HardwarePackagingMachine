/*
 * File:   main.c
 * Author: Michael Ding
 *
 * Created on July 18, 2016, 12:11 PM
 *
 * Edited by Tyler Gamvrelis, summer 2017
 *
 * Description: Demonstration of printing to the character LCD.
 * 
 * Precondition:
 *   1. Character LCD is in a PIC socket
 */

/***** Includes *****/
#include <xc.h>
#include <stdio.h> // This gives us access to the standard print formatting library
#include "configBits.h"
#include "constants.h"

/***** Function prototypes *****/
void initLCD(void);
void lcdInst(char data) ;
void putch(char data);
void lcdNibble(char data);

void initLCD(void) {
    __delay_ms(15);
    /* For reference, LCD instructions can be found in the controller datasheet
     * included with the sample code. Alternatively, it can be found here:
     * https://www.sparkfun.com/datasheets/LCD/HD44780.pdf  */
    lcdInst(0b00110011);
    lcdInst(0b00110010);
    lcdInst(0b00101000);
    lcdInst(0b00001111);
    lcdInst(0b00000110);
    lcdInst(0b00000001);
    __delay_ms(15);
}

void lcdInst(char data) {
    /* Sends a command to a display control register. */

    RS = 0;
    lcdNibble(data);
    __delay_us(100);
}

void putch(char data){
    /* Sends a character to the display RAM for printing. */

    RS = 1;
    lcdNibble(data);
    __delay_us(100);
}

void lcdNibble(char data){
    /* This function takes care of the low-level byte-sending 
     * implementation. */


    /* Send the 4 least significant bits (LSb). */
    char temp = data & 0xF0;
    LATD = LATD & 0x0F;
    LATD = temp | LATD;

    /* These next 4 lines pulse the "enable" line of the
     * character LCD, which causes its memory registers to
     * latch the data we just wrote onto LATD. */
    E = 0;
    __delay_us(LCD_DELAY);
    E = 1;    
    __delay_us(100);
    
    /* Send the 4 most significant bits (MSb). */
    data = data << 4;
    temp = data & 0xF0;
    LATD = LATD & 0x0F;
    LATD = temp | LATD;
    E = 0;
    __delay_us(LCD_DELAY);
    E = 1;
    __delay_us(100);
}


void main(void) {
    OSCCON = 0xF2; // Set internal oscillator to 8 MHz, and enforce internal oscillator operation
    TRISD = 0x00; // Set the data direction for all pins on port D to output
    
    initLCD();
    printf("Hello World! :)");
    
    /* Do nothing, forever. */
    while(1);
}
