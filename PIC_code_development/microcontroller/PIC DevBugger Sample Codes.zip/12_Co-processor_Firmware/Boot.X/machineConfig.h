/* 
 * File:   machineConfig.h
 * Author: Tyler Gamvrelis
 *
 * Created on July 10, 2017, 10:44 AM
 */

#ifndef MACHINECONFIG_H
#define	MACHINECONFIG_H

#ifdef	__cplusplus
extern "C" {
#endif

void machineConfig(void);


#ifdef	__cplusplus
}
#endif

#endif	/* MACHINECONFIG_H */

